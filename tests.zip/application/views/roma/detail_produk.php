<div class="container-fluid py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>">Home</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo base_url();?>home/produk">Produk</a></li>
                    <li class="breadcrumb-item active" aria-current="page">nama produk</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-3">
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <img src="<?php echo base_url(); ?>asset/images/<?php echo $detail["tshirt_image"] ?>" class="img-fluid rounded" alt="<?php echo $detail['tshirt_name'];?>">
            </div>

            <div class="col-md-6">
                <h2 class="text-gray"><?php echo $detail["tshirt_name"]; ?></h2>
                <h6 class="text-gray"><?php echo $detail["brand_name"] ?></h6>
                <p class="text-gray"><?php echo $detail["product_description"] ?></p>
            </div>

            <div class="col-md-3">
            <p class="text-gray">qty</p>
                <input type="number" value="1" class="form-control mb-3">
                <button class="btn btn-danger btn-block"><i class="fa fa-cart-plus"></i> beli</button>
                <button class="btn btn-success btn-block"><i class="fa fa-whatsapp"></i> beli via whatsapp</button>
            </div>
        </div>
    </div>
</div>